import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

declare var google: any; //declare global variable

@IonicPage()
@Component({
  selector: 'page-search',
  templateUrl: 'search.html',
})
export class SearchPage {
locationItems:any[];
autocomplete:any;
locationService:any;
location = {};//added from example code
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
  ) {
    this.locationService = new google.maps.places.AutocompleteService();
    this.autocomplete = {
      city: ''
    }
  }
GetCityName(){
  if(this.autocomplete.city =='') {
    this.locationItems =[];
    return;
  }
  //self gives us access to the windows object - method is a function inside an object
  let self = this;
  let config = {
    types:['geocode'],
    input: this.autocomplete.city

  }
  this.locationService.getPlacePredictions(config, (predictions,status) => {
    self.locationItems = [];
    console.log(predictions);

  })
}
  
}
